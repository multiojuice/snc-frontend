import numpy as np
import matplotlib.pyplot as plt
import matplotlib.colors as col
import cv2
import sys
from urllib.request import urlopen
from scipy.ndimage import gaussian_filter
from scipy.spatial import Voronoi, voronoi_plot_2d
import imageio
import pandas as pd
from skimage.transform import resize
from sklearn.cluster import KMeans

from flask import Flask,render_template, request
from flask import jsonify
from flask import send_file
from flask_cors import CORS, cross_origin
import os
import cloudinary
import cloudinary.uploader
import sys
from convolve import mosaicize
app = Flask(__name__)

from dotenv import load_dotenv
load_dotenv()

cloudinary.config(cloud_name = os.getenv('CLOUD_NAME'), api_key=os.getenv('API_KEY'), 
    api_secret=os.getenv('API_SECRET'))

# After creating the Flask app, you can make all APIs allow cross-origin access.
CORS(app)

@app.route("/")
def handle_home():
    return "Hello world!"

# or a specific API
@app.route("/upload", methods=['POST'])
def upload_file():
  app.logger.info('in upload route')
  upload_result = None
  if request.method == 'POST':
    file_to_upload = request.files['file']
    app.logger.info('%s file_to_upload', file_to_upload)
    if file_to_upload:
      upload_result = cloudinary.uploader.upload(file_to_upload)
      app.logger.info(upload_result)
      return jsonify(upload_result)

@app.route("/transform", methods=['POST'])
def transform_by_url():

  url = request.json["url"]
  num_panes = request.json["panes"]

  #exec(open("convolve.py").read())

  mosaicize(url, "my-image.svg", num_panes)

  return send_file("my-image.svg", mimetype='image/svg')

    


app.run(host='0.0.0.0', port=3000)
