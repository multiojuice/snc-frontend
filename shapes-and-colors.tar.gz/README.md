# Shapes and Colors
A computational geometry project by Daria Chaplin, Owen Sullivan, and Collin Tod

## Edge Detection
Edge detection here is achieved via use of the [Sobel operator](https://en.wikipedia.org/wiki/Sobel_operator) in the `convolve.py` file. To run edge detection on an image, run the following command (assuming all of `requirements.txt` is satisfied):
```
convolve.py <img_in_url> <img_out_path> <number of voronoi panes>
```
This implementation relies on python loops as opposed to the [Fast Fourier Transform](https://en.wikipedia.org/wiki/Fast_Fourier_transform) for now, so convolution may be a little slow. Performance improvements will hopefully be made.

## Color Palette
A k-means algorithm is utilized to determine the color palette of an image. Then, each pixel is replaced with the cluster color that is closest to its own color. To run this program, run the following command (again assuming the `requirements.txt` is satisfied):
```
python3 color_palette.py <img_url>
```
This implementation is based on strategies introduced in this [Colab](https://colab.research.google.com/drive/1EWcej7Hm2F_tGf7-SB2UX6uJ-5QvCEKb).
