import sys
import pandas as pd
from matplotlib import pyplot as plt
from imageio import imread
from skimage.transform import resize
from sklearn.cluster import KMeans

# Read image file from URL argument as 2D array of RGB values
filepath = sys.argv[1]
img = imread(filepath)

# Resize the image and get each pixel as an array of RGB values
img = resize(img, (200, 200))
data = pd.DataFrame(img.reshape(-1, 3), columns=['R', 'G', 'B'])

# Cluster the pixels into given number of colors based on the RGB value
k_means = KMeans(n_clusters=8, random_state=0)
data['Cluster'] = k_means.fit_predict(data)

# Get color palette from cluster centers
palette = k_means.cluster_centers_
palette_list = []
for color in palette:
    palette_list.append([[tuple(color)]])

# Replace every pixel's color with the color of its cluster centroid
data['R_cluster'] = data['Cluster'].apply(lambda x: palette_list[x][0][0][0])
data['G_cluster'] = data['Cluster'].apply(lambda x: palette_list[x][0][0][1])
data['B_cluster'] = data['Cluster'].apply(lambda x: palette_list[x][0][0][2])

# Convert the dataframe back to a numpy array
img_c = data[['R_cluster', 'G_cluster', 'B_cluster']].values

# Reshape the data back to a 200x200 image and then resize to original aspect ratio
img_c = img_c.reshape(200, 200, 3)
img_c = resize(img_c, (800, 1200))

# Display the image
plt.axis('off')
plt.imshow(img_c)
plt.show()
