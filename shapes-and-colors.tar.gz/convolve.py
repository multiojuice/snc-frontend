import numpy as np
import matplotlib.pyplot as plt
import matplotlib.colors as col
import cv2
import sys
from urllib.request import urlopen
from scipy.ndimage import gaussian_filter
from scipy.spatial import Voronoi, voronoi_plot_2d
import imageio
import pandas as pd
from skimage.transform import resize
from sklearn.cluster import KMeans

sobel_x = np.array([[-1, 0, 1],
                    [-2, 0, 2],
                    [-1, 0, 1]])

sobel_x2 = np.fliplr(sobel_x)

sobel_y = np.array([[-1, -2, -1],
                    [0, 0, 0],
                    [1, 2, 1]])

sobel_y2 = np.flipud(sobel_y)

blur_size = 9
# huge uniform blur
blur = np.full((blur_size, blur_size), 1 / (blur_size ** 2))


def color_palette(img):
    # Resize the image and get each pixel as an array of RGB values
    orig_shape = img.shape
    img = resize(img, (200, 200))
    data = pd.DataFrame(img.reshape(-1, 3), columns=['R', 'G', 'B'])

    # Cluster the pixels into given number of colors based on the RGB value
    k_means = KMeans(n_clusters=10, random_state=0)
    data['Cluster'] = k_means.fit_predict(data)

    # Get color palette from cluster centers
    palette = k_means.cluster_centers_
    palette_list = []
    for color in palette:
        palette_list.append([[tuple(color)]])

    # Replace every pixel's color with the color of its cluster centroid
    data['R_cluster'] = data['Cluster'].apply(lambda x: palette_list[x][0][0][0])
    data['G_cluster'] = data['Cluster'].apply(lambda x: palette_list[x][0][0][1])
    data['B_cluster'] = data['Cluster'].apply(lambda x: palette_list[x][0][0][2])

    # Convert the dataframe back to a numpy array
    result_img = data[['R_cluster', 'G_cluster', 'B_cluster']].values

    # Reshape the data back to a 200x200 image and then resize to original aspect ratio
    result_img = result_img.reshape(200, 200, 3)
    result_img = resize(result_img, (orig_shape[0], orig_shape[1]))

    return result_img


def convolve(kernel, img):
    """
    Given a nxn image kernel, performs a convolution of that kernel over the
    img array. Is not particularly fast since it relies on python loops, maybe
    look into vectorizing with numpy later if we have time?
    """
    output = np.empty_like(img)

    pad_size = kernel.shape[0] // 2

    # Pads the image
    img = np.pad(img, ((pad_size, pad_size), (pad_size, pad_size)), mode='edge')

    for i in range(img.shape[0] - (kernel.shape[0]-1)):
        for j in range(img.shape[1] - (kernel.shape[0]-1)):
            
            # A lot is happening here:
            #   performs element-wise multiplication w/ a submatrix of the original image and the kernel
            #   takes the sum of the resulting matrix
            output[i, j] = max(min((kernel * img[i:i+kernel.shape[0], j:j+kernel.shape[0]]).sum(), 255), 0)
    return output


def sample_prob(dist, n):



    # TODO figure out why this is flipped like it is
    flat = dist.flatten()

    samples = []
    for i in range(n):
        sample_idx = np.random.choice(a=flat.size, p=flat)
        adjusted_idx = np.unravel_index(sample_idx, dist.shape)
        samples.append((adjusted_idx[0], adjusted_idx[1]))
    return samples


def main():

    if len(sys.argv) != 4:
        print("usage: convolve.py <img_in_url> <img_out_path> <number of voronoi panes>")
        sys.exit(1)

    mosaicize(sys.argv[1], sys.argv[2], int(sys.argv[3]))

def mosaicize(img_in_url, img_out_fname, num_panes):

    resp = urlopen(img_in_url)
    img_arr = np.asarray(bytearray(resp.read()), dtype="uint8")
    #img_arr = np.asarray(cv2.imread(sys.argv[1]))
    img_in = cv2.imdecode(img_arr, cv2.IMREAD_GRAYSCALE)
    #img_color = cv2.imread(sys.argv[1], cv2.IMREAD_COLOR)

    img_color = cv2.imdecode(img_arr, cv2.IMREAD_COLOR)
    #img_color = color_palette(imageio.imread(sys.argv[1]))
    # plt.axis('off')
    # plt.imshow(img_color)
    # plt.show()

    # Each of these convolution results are edges in a different direction
    convoluted = convolve(sobel_y, img_in)
    convoluted2 = convolve(sobel_y2, img_in)
    convoluted3 = convolve(sobel_x, img_in)
    convoluted4 = convolve(sobel_x2, img_in)

    # Combine all the sobels for omnidirectional edges
    convoluted_final_manual = (convoluted + convoluted2) / 2 + (convoluted3 + convoluted4) / 2

    #plt.imshow(convoluted_final_manual)
    #plt.title("Detected Edges")
    #plt.show()

    #cv2.imwrite(img_out_fname + '-edges', convoluted_final_manual)

    # TODO figure out optimal std. deviation
    # Blur edges to get high intensities around edges
    blurred = gaussian_filter(convoluted_final_manual, sigma=5)

    #plt.imshow(blurred)
    #plt.title("Blurred Edges")
    #plt.show()

    #cv2.imwrite(img_out_fname + '-blurred', blurred)

    # Create an image that has low intensities on edges, but high around edges
    subtracted = np.clip(blurred - convoluted_final_manual, 0, 255)
    #cv2.imwrite(img_out_fname + '-distribution', subtracted)

    #plt.imshow(subtracted)
    #plt.title("Probability Distribution for Voronoi Points")
    #plt.show()
    subtracted = subtracted.astype(float)
    subtracted = subtracted / subtracted.sum()


    # Transpose and flip since images are column major w origin in top left
    corrected_subbed = np.fliplr(subtracted.T)
    corrected_img_color = np.swapaxes(np.flipud(img_color), 0,1)

    # TODO add crazy distant points to this to bound the outer voronoi regions
    samples = sample_prob(corrected_subbed, num_panes)
    vor = Voronoi(samples)
    #voronoi_plot_2d(vor, show_vertices=False, show_points=False)

    #plt.title("Uncolored Voronoi")
    #plt.show()

    fig = voronoi_plot_2d(vor, show_vertices=False, show_points=False)
    fig.set_size_inches(20, img_in.shape[0] / img_in.shape[1] * 20)
    normalizer = col.Normalize(vmin=0, vmax=255)

    # Color in the polygons
    for i in range(len(vor.point_region)):
        region = vor.regions[vor.point_region[i]]
        point = tuple(map(int, vor.points[i]))
        if -1 not in region:
            polygon = [vor.vertices[i] for i in region]
            color = list(map(normalizer, np.flip(corrected_img_color[point])))
            #color = list(map(normalizer, corrected_img_color[point]))
            plt.fill(*zip(*polygon), color=color)

    ax = plt.gca()
    ax.set_aspect(img_in.shape[0] / img_in.shape[1])
    plt.axis('off')
    plt.savefig(img_out_fname)

    return convoluted_final_manual, blurred, subtracted


if __name__ == "__main__":
    main()
